package com.example.thecalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

public class BMITest extends AppCompatActivity {

    ImageView btn_return;
    TextView btn_test;
    TextView tv_result;
    EditText height;
    EditText weight;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bmi_test);

        btn_return = findViewById(R.id.btn_bmi_return);
        btn_return.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        tv_result = findViewById(R.id.bmi_result);
        height = findViewById(R.id.bmi_height);
        weight = findViewById(R.id.bmi_weight);
        btn_test = findViewById(R.id.btn_bmi_test);
        btn_test.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Float height_num = Float.parseFloat(String.valueOf(height.getText()))/100;
                Float weight_num = Float.parseFloat(String.valueOf(weight.getText()));
                Float result_num = weight_num/(height_num*height_num);
                String result = String.valueOf(result_num);
                tv_result.setText(result);
            }
        });
    }
}