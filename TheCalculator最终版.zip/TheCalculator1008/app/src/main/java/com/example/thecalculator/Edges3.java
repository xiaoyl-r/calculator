package com.example.thecalculator;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Edges3 extends AppCompatActivity {

    ImageView btn_return;
    TextView btn_circle;
    TextView btn_triangle;
    TextView btn_rhomboid;
    TextView btn_ring;
    TextView btn_ball;
    TextView btn_ellipse;
    EditText circle_r;
    EditText circle_degree;
    EditText triangle_a;
    EditText triangle_b;
    EditText triangle_c;
    EditText rhomboid_a;
    EditText rhomboid_b;
    EditText rhomboid_degree;
    EditText ring_R;
    EditText ring_r;
    EditText ring_degree;
    EditText ball_r;
    EditText ellipse_R;
    EditText ellipse_r;
    TextView ballresult;
    TextView circleresult;
    TextView triangleresult;
    TextView rhomboidresult;
    TextView ringresult;
    TextView ellipseresult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edges3);

        btn_return = findViewById(R.id.btn_edge_return);
        btn_return.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        btn_ball = findViewById(R.id.btn_ball);
        btn_circle = findViewById(R.id.btn_circle);
        btn_ellipse = findViewById(R.id.btn_ellipse);
        btn_rhomboid = findViewById(R.id.btn_rhomboid);
        btn_ring = findViewById(R.id.btn_ring);
        btn_triangle = findViewById(R.id.btn_triangle);
        circle_r = findViewById(R.id.edittext_circle1);
        circle_degree = findViewById(R.id.edittext_circle2);
        triangle_a = findViewById(R.id.edittext_triangle1);
        triangle_b = findViewById(R.id.edittext_triangle2);
        triangle_c = findViewById(R.id.edittext_triangle3);
        rhomboid_a = findViewById(R.id.edittext_rhomboid1);
        rhomboid_b = findViewById(R.id.edittext_rhomboid2);
        rhomboid_degree = findViewById(R.id.edittext_rhomboid3);
        ring_R = findViewById(R.id.edittext_ring1);
        ring_r = findViewById(R.id.edittext_ring2);
        ring_degree = findViewById(R.id.edittext_ring3);
        ball_r = findViewById(R.id.edittext_ball);
        ellipse_R = findViewById(R.id.edittext_ellipse1);
        ellipse_r = findViewById(R.id.edittext_ellipse2);
        ballresult = findViewById(R.id.ball_result);
        circleresult = findViewById(R.id.circle_result);
        triangleresult = findViewById(R.id.triangle_result);
        rhomboidresult = findViewById(R.id.rhomboid_result);
        ringresult = findViewById(R.id.ring_result);
        ellipseresult = findViewById(R.id.ellipse_result);

        btn_ball.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(ball_r.length()==0){
                    ball_r.setHintTextColor(getResources().getColor(R.color.red));
                    ball_r.setBackground(getResources().getDrawable(R.drawable.redframe));
                }else{
                    ball_r.setHintTextColor(getResources().getColor(R.color.gray));
                    ball_r.setBackground(getResources().getDrawable(R.drawable.result));
                    int r = Integer.parseInt(ball_r.getText().toString());
                    String S = String.valueOf(Math.round(4 * Math.PI * r * r*100)/100.0);
                    String V = String.valueOf(Math.round(4*100* Math.PI * r * r * r/3)/100.0);
                    ballresult.setText("表面积："+S+"\n体积："+V);
                }
            }
        });
        btn_triangle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(triangle_a.length()==0 || triangle_b.length()==0 || triangle_c.length()==0){
                    if(triangle_a.length()==0){
                        triangle_a.setHintTextColor(getResources().getColor(R.color.red));
                        triangle_a.setBackground(getResources().getDrawable(R.drawable.redframe));
                    }
                    if(triangle_b.length()==0){
                        triangle_b.setHintTextColor(getResources().getColor(R.color.red));
                        triangle_b.setBackground(getResources().getDrawable(R.drawable.redframe));
                    }
                    if(triangle_c.length()==0){
                        triangle_c.setHintTextColor(getResources().getColor(R.color.red));
                        triangle_c.setBackground(getResources().getDrawable(R.drawable.redframe));
                    }
                }else {
                    triangle_a.setHintTextColor(getResources().getColor(R.color.gray));
                    triangle_a.setBackground(getResources().getDrawable(R.drawable.result));
                    triangle_b.setHintTextColor(getResources().getColor(R.color.gray));
                    triangle_b.setBackground(getResources().getDrawable(R.drawable.result));
                    triangle_c.setHintTextColor(getResources().getColor(R.color.gray));
                    triangle_c.setBackground(getResources().getDrawable(R.drawable.result));
                    int a = Integer.parseInt(triangle_a.getText().toString());
                    int b = Integer.parseInt(triangle_b.getText().toString());
                    int c = Integer.parseInt(triangle_c.getText().toString());
                    String C = String.valueOf((Math.round((a+b+c)*100)/100.0));
                    if(Math.round((a+b+c)*(a+b-c)*(a+c-b)*(b+c-a)*100/16)/100.0<=0){
                        triangleresult.setText("不能构成三角形");
                    }else{
                        String S = String.valueOf(Math.sqrt(Math.round((a+b+c)*(a+b-c)*(a+c-b)*(b+c-a)*100/16)/100.0));
                        triangleresult.setText("周长："+C+"\n面积："+S);
                    }
                }
            }
        });
        btn_ring.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(ring_R.length()==0 || ring_r.length()==0){
                    if(ring_R.length()==0){
                        ring_R.setHintTextColor(getResources().getColor(R.color.red));
                        ring_R.setBackground(getResources().getDrawable(R.drawable.redframe));
                    }
                    if(ring_r.length()==0){
                        ring_r.setHintTextColor(getResources().getColor(R.color.red));
                        ring_r.setBackground(getResources().getDrawable(R.drawable.redframe));
                    }
                }else{
                    ring_R.setHintTextColor(getResources().getColor(R.color.gray));
                    ring_R.setBackground(getResources().getDrawable(R.drawable.result));
                    ring_r.setHintTextColor(getResources().getColor(R.color.gray));
                    ring_r.setBackground(getResources().getDrawable(R.drawable.result));
                    int R = Integer.parseInt(ring_R.getText().toString());
                    int r = Integer.parseInt(ring_r.getText().toString());
                    int degree=360;
                    if(ring_degree.length()!=0){
                        degree = Integer.parseInt(ring_degree.getText().toString());
                    }
                    double l1 = Math.round(degree*2*Math.PI*r*100/360)/100.0;
                    double l2 = Math.round(degree*2*Math.PI*R*100/360)/100.0;
                    String l = String.valueOf(l1);
                    String L = String.valueOf(l2);
                    String C = String.valueOf(Math.round((l1+l2+2*(R-r))*100)/100.0);
                    String S = String.valueOf(Math.round(degree*Math.PI*(R*R-r*r))*100/360/100.0);
                    ringresult.setText("内弧长："+l+"\n外弧长："+L+"\n周长："+C+"\n面积："+S);
                }

            }
        });
        btn_rhomboid.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(rhomboid_a.length()==0 || rhomboid_b.length()==0 || rhomboid_degree.length()==0){
                    if(rhomboid_a.length()==0){
                        rhomboid_a.setHintTextColor(getResources().getColor(R.color.red));
                        rhomboid_a.setBackground(getResources().getDrawable(R.drawable.redframe));
                    }
                    if(rhomboid_b.length()==0){
                        rhomboid_b.setHintTextColor(getResources().getColor(R.color.red));
                        rhomboid_b.setBackground(getResources().getDrawable(R.drawable.redframe));
                    }
                    if(rhomboid_degree.length()==0){
                        rhomboid_degree.setHintTextColor(getResources().getColor(R.color.red));
                        rhomboid_degree.setBackground(getResources().getDrawable(R.drawable.redframe));
                    }
                }else{
                    rhomboid_a.setHintTextColor(getResources().getColor(R.color.gray));
                    rhomboid_a.setBackground(getResources().getDrawable(R.drawable.result));
                    rhomboid_b.setHintTextColor(getResources().getColor(R.color.gray));
                    rhomboid_b.setBackground(getResources().getDrawable(R.drawable.result));
                    rhomboid_degree.setHintTextColor(getResources().getColor(R.color.gray));
                    rhomboid_degree.setBackground(getResources().getDrawable(R.drawable.result));
                    int a = Integer.parseInt(rhomboid_a.getText().toString());
                    int b = Integer.parseInt(rhomboid_b.getText().toString());
                    double degree = Integer.parseInt(rhomboid_degree.getText().toString());
                    double sina = Math.sin(Math.toRadians(degree));
                    String C = String.valueOf(Math.round(a*2+b*2)*100/100.0);
                    String S = String.valueOf(Math.round(a*sina*b)*100/100.0);
                    rhomboidresult.setText("周长："+C+"\n面积："+S);
                }
            }
        });
        btn_ellipse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(ellipse_R.length()==0 || ellipse_r.length()==0){
                    if(ellipse_R.length()==0){
                        ellipse_R.setHintTextColor(getResources().getColor(R.color.red));
                        ellipse_R.setBackground(getResources().getDrawable(R.drawable.redframe));
                    }
                    if(ellipse_r.length()==0){
                        ellipse_r.setHintTextColor(getResources().getColor(R.color.red));
                        ellipse_r.setBackground(getResources().getDrawable(R.drawable.redframe));
                    }
                }else{
                    ellipse_R.setHintTextColor(getResources().getColor(R.color.gray));
                    ellipse_R.setBackground(getResources().getDrawable(R.drawable.result));
                    ellipse_r.setHintTextColor(getResources().getColor(R.color.gray));
                    ellipse_r.setBackground(getResources().getDrawable(R.drawable.result));
                    int R = Integer.parseInt(ellipse_R.getText().toString());
                    int r = Integer.parseInt(ellipse_r.getText().toString());
                    String C = String.valueOf(Math.round(Math.PI*r+2*(R-r))*100/100.0);
                    String S = String.valueOf(Math.round(Math.PI*R*r/4)*100/100.0);
                    ellipseresult.setText("周长："+C+"\n面积："+S);
                }
            }
        });
        btn_circle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(circle_r.length()==0 || circle_degree.length()==0){
                    if(circle_r.length()==0){
                        circle_r.setHintTextColor(getResources().getColor(R.color.red));
                        circle_r.setBackground(getResources().getDrawable(R.drawable.redframe));
                    }
                    if(circle_degree.length()==0){
                        circle_degree.setHintTextColor(getResources().getColor(R.color.red));
                        circle_degree.setBackground(getResources().getDrawable(R.drawable.redframe));
                    }
                }else{
                    circle_r.setHintTextColor(getResources().getColor(R.color.gray));
                    circle_r.setBackground(getResources().getDrawable(R.drawable.result));
                    circle_degree.setHintTextColor(getResources().getColor(R.color.gray));
                    circle_degree.setBackground(getResources().getDrawable(R.drawable.result));
                    int r = Integer.parseInt(circle_r.getText().toString());
                    int degree = Integer.parseInt(circle_degree.getText().toString());
                    String l = String.valueOf(Math.round(degree*2*Math.PI*r*100/360)/100.0);
                    String C = String.valueOf(Math.round(2*Math.PI*r)*100/100.0);
                    String S = String.valueOf(Math.round(degree*Math.PI*r*r)*100/360/100.0);
                    circleresult.setText("弧长："+l+"\n周长："+C+"\n面积："+S);
                }
            }
        });
    }
}