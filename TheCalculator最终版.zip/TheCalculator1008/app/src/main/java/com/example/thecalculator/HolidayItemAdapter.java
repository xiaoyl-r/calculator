package com.example.thecalculator;

import android.app.Activity;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class HolidayItemAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder>{

    private List<HolidayItem> mDatas;
    private int TYPE_TOP = 1000;
    private int TYPE_OTHERS = 1001;

    public HolidayItemAdapter(List<HolidayItem> holidayItems){
        this.mDatas = holidayItems;
    }

    @Override
    public int getItemViewType(int position) {
        if (position == 0) {
            return TYPE_TOP;
        } else {
            return TYPE_OTHERS;
        }
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if (viewType == TYPE_TOP) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.holiday_top, parent, false);
            return new HolidayItemAdapter.TopInnerholder(view);
        } else {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.holiday_items, parent, false);
            return new HolidayItemAdapter.Innerholder(view);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        if (holder instanceof HolidayItemAdapter.TopInnerholder) {
            HolidayItemAdapter.TopInnerholder topInnerholder = (HolidayItemAdapter.TopInnerholder) holder;
            topInnerholder.setData(mDatas.get(position));
        } else {
            HolidayItemAdapter.Innerholder innerholder = (HolidayItemAdapter.Innerholder) holder;
            innerholder.setData(mDatas.get(position));
        }
    }

    @Override
    public int getItemCount() {
        return mDatas.size();
    }

    public class TopInnerholder extends RecyclerView.ViewHolder {
        private TextView context;
        private TextView time;
        private ImageView btn_return;
        private TextView tv_year;
        private TextView tv_month;
        private TextView tv_day;

        public TopInnerholder(View itemView) {
            super(itemView);
            //找到条目控件
            context = itemView.findViewById(R.id.holiday_top_text);
            time=itemView.findViewById(R.id.holiday_top_days);
            btn_return = itemView.findViewById(R.id.btn_holiday_return);
            tv_year = itemView.findViewById(R.id.text_holiday_year);
            tv_month = itemView.findViewById(R.id.text_holiday_month);
            tv_day = itemView.findViewById(R.id.text_holiday_day);
        }
        //这个函数用于设置数据
        public void setData(HolidayItem holidayItem) {
            //开始设置数据
            context.setText(holidayItem.getText());
            time.setText(holidayItem.getTime());
            btn_return.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Activity activity = (Activity) itemView.getContext();
                    activity.finish();
                }
            });
            Calendar calendar = Calendar.getInstance();  //当前日期
            SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
            Date current_date = calendar.getTime();
            String year = String.valueOf(1900+current_date.getYear());
            int month_value = current_date.getMonth();
            String month = "Jan_Feb_Mar_Apr_May_Jun_Jul_Aug_Sep_Oct_Nov_Dec".substring(month_value*4,month_value*4+3);
            String day = String.valueOf(current_date.getDate());
            tv_year.setText(year);
            tv_month.setText(month);
            tv_day.setText(day);
        }
    }

    public class Innerholder extends RecyclerView.ViewHolder {
        private TextView context;
        private TextView time;

        public Innerholder(View itemView) {
            super(itemView);
            //找到条目控件
            context = itemView.findViewById(R.id.holiday_item_text);
            time=itemView.findViewById(R.id.holiday_item_days);
        }
        //这个函数用于设置数据
        public void setData(HolidayItem holidayItem) {
            //开始设置数据
            context.setText(holidayItem.getText());
            time.setText(holidayItem.getTime());
        }
    }
}
