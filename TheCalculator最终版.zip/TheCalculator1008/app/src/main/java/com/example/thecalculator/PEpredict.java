package com.example.thecalculator;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class PEpredict extends AppCompatActivity {

    ImageView btn_return;
    EditText running;
    EditText swimming;
    EditText gym;
    EditText skipping;
    EditText free;
    TextView btn_test;
    TextView tv_year;
    TextView tv_month;
    TextView tv_day;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pepredict);

        btn_return = findViewById(R.id.btn_pe_return);
        btn_return.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        tv_year = findViewById(R.id.text_pe_year);
        tv_month = findViewById(R.id.text_pe_month);
        tv_day = findViewById(R.id.text_pe_day);
        running = findViewById(R.id.et_running);
        swimming = findViewById(R.id.et_swimming);
        gym = findViewById(R.id.et_gym);
        skipping = findViewById(R.id.et_skipping);
        free = findViewById(R.id.et_free);
        btn_test = findViewById(R.id.pe_test);
        btn_test.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int Swim = 0;
                if (swimming.length() != 0) {
                    Swim = Integer.parseInt(swimming.getText().toString());
                }
                int Skip = 0;
                if (skipping.length() != 0) {
                    Skip = Integer.parseInt(skipping.getText().toString());
                }
                int Gym = 0;
                if (gym.length() != 0) {
                    Gym = Integer.parseInt(gym.getText().toString());
                }
                int Run = 0;
                if (running.length() != 0) {
                    Run = Integer.parseInt(running.getText().toString());
                }
                int Free = 0;
                if (free.length() != 0) {
                    Free = Integer.parseInt(free.getText().toString());
                }

                int total = Swim + Skip + Gym + Run;
                int week_num = (80 - Free) / total;
                int day_num = (80 - Free) % total;

                Calendar calendar = Calendar.getInstance();  //当前日期
                SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
                calendar.add(Calendar.DAY_OF_YEAR, week_num * 7 + day_num);
                Date result = calendar.getTime();
                String year = String.valueOf(1900 + result.getYear());
                int month_value = result.getMonth();
                String month = "Jan_Feb_Mar_Apr_May_Jun_Jul_Aug_Sep_Oct_Nov_Dec".substring(month_value * 4, month_value * 4 + 3);
                String day = String.valueOf(result.getDate());
                tv_year.setText(year);
                tv_month.setText(month);
                tv_day.setText(day);
            }
        });
    }
}