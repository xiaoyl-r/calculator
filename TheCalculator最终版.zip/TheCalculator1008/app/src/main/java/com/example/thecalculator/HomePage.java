package com.example.thecalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.animation.ValueAnimator;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.widget.PopupWindow;
import android.widget.TextView;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

public class HomePage extends AppCompatActivity {

    private TextView sin,cos,tan,cot,more;
    private TextView process,result;
    private TextView ans,allClear,clear,divide;
    private TextView button7,button8,button9,multiply;
    private TextView button4,button5,button6,minus;
    private TextView button1,button2,button3,plus;
    private TextView button0,dot,equals;
    private TextView zuokuohao,youkuohao;
    private String ANS="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);
        //获取id
        sin = findViewById(R.id.sin);
        cos = findViewById(R.id.cos);
        tan = findViewById(R.id.tan);
        cot = findViewById(R.id.cot);
        more = findViewById(R.id.more);
        process = findViewById(R.id.process);
        result = findViewById(R.id.result);
        ans = findViewById(R.id.ans);
        allClear = findViewById(R.id.allClear);
        clear = findViewById(R.id.clear);
        divide = findViewById(R.id.divide);
        button7 = findViewById(R.id.button7);
        button8 = findViewById(R.id.button8);
        button9 = findViewById(R.id.button9);
        multiply = findViewById(R.id.multiply);
        button4 = findViewById(R.id.button4);
        button5 = findViewById(R.id.button5);
        button6 = findViewById(R.id.button6);
        minus = findViewById(R.id.minus);
        button1 = findViewById(R.id.button1);
        button2 = findViewById(R.id.button2);
        button3 = findViewById(R.id.button3);
        plus = findViewById(R.id.plus);
        button0 = findViewById(R.id.button0);
        dot = findViewById(R.id.dot);
        equals = findViewById(R.id.equals);
        zuokuohao = findViewById(R.id.zuokuohao);
        youkuohao = findViewById(R.id.youkuohao);


        more.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showPopupWindow_more();
            }
        });

        //设置监听事件
        //用list存储当前算式
        List<String> formula = new ArrayList<>();
        sin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                formula.add(sin.getText().toString());
                formula.add("(");
                String str="";
                for (int i=0;i<formula.size();i++){
                    str+=formula.get(i);
                }
                process.setText(str);
            }
        });
        cos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                formula.add(cos.getText().toString());
                formula.add("(");
                String str="";
                for (int i=0;i<formula.size();i++){
                    str+=formula.get(i);
                }
                process.setText(str);
            }
        });
        tan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                formula.add(tan.getText().toString());
                formula.add("(");
                String str="";
                for (int i=0;i<formula.size();i++){
                    str+=formula.get(i);
                }
                process.setText(str);

            }
        });
        cot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                formula.add(cot.getText().toString());
                formula.add("(");
                String str="";
                for (int i=0;i<formula.size();i++){
                    str+=formula.get(i);
                }
                process.setText(str);

            }
        });

        ans.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(ANS.equals("")){
                    process.setText("");
                } else {
                    String res=ANS;
                    for(int i=0;i<res.length();i++){
                        formula.add(res.substring(i,i+1));
                    }
                    String str="";
                    for (int i=0;i<formula.size();i++){
                        str+=formula.get(i);
                    }
                    process.setText(str);
                }
            }
        });
        allClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                formula.clear();
                process.setText("");
                result.setText("");
            }
        });
        clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!formula.isEmpty()){
                formula.remove(formula.size()-1);
                }
                String str="";
                for (int i=0;i<formula.size();i++){
                    str+=formula.get(i);
                }
                process.setText(str);

            }
        });
        divide.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(formula.isEmpty()){
                    process.setText("");
                }else if(!isOperator(formula.get(formula.size()-1))) {
                    formula.add(divide.getText().toString());
                }
                String str="";
                for (int i=0;i<formula.size();i++){
                    str+=formula.get(i);
                }
                process.setText(str);
            }
        });
        button7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                formula.add(button7.getText().toString());
                String str="";
                for (int i=0;i<formula.size();i++){
                    str+=formula.get(i);
                }
                process.setText(str);
            }

        });
        button8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                formula.add(button8.getText().toString());
                String str="";
                for (int i=0;i<formula.size();i++){
                    str+=formula.get(i);
                }
                process.setText(str);

            }
        });
        button9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                formula.add(button9.getText().toString());
                String str="";
                for (int i=0;i<formula.size();i++){
                    str+=formula.get(i);
                }
                process.setText(str);

            }
        });
        multiply.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {   //防止同时输入两个四则运算符导致报错
                if(formula.isEmpty()){
                    process.setText("");
                }else if(!isOperator(formula.get(formula.size()-1))) {
                    formula.add(multiply.getText().toString());
                }
                String str="";
                for (int i=0;i<formula.size();i++){
                    str+=formula.get(i);
                }
                process.setText(str);

            }
        });
        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                formula.add(button4.getText().toString());
                String str="";
                for (int i=0;i<formula.size();i++){
                    str+=formula.get(i);
                }
                process.setText(str);

            }
        });
        button5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                formula.add(button5.getText().toString());
                String str="";
                for (int i=0;i<formula.size();i++){
                    str+=formula.get(i);
                }
                process.setText(str);

            }
        });
        button6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                formula.add(button6.getText().toString());
                String str="";
                for (int i=0;i<formula.size();i++){
                    str+=formula.get(i);
                }
                process.setText(str);

            }
        });
        minus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(formula.isEmpty() || !isOperator(formula.get(formula.size()-1))) {
                    formula.add(minus.getText().toString());
                }
                String str="";
                for (int i=0;i<formula.size();i++){
                    str+=formula.get(i);
                }
                process.setText(str);

            }
        });
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                formula.add(button1.getText().toString());
                String str="";
                for (int i=0;i<formula.size();i++){
                    str+=formula.get(i);
                }
                process.setText(str);

            }
        });
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                formula.add(button2.getText().toString());
                String str="";
                for (int i=0;i<formula.size();i++){
                    str+=formula.get(i);
                }
                process.setText(str);

            }
        });
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                formula.add(button3.getText().toString());
                String str="";
                for (int i=0;i<formula.size();i++){
                    str+=formula.get(i);
                }
                process.setText(str);

            }
        });
        plus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(formula.isEmpty()){
                    process.setText("");
                }else if(!isOperator(formula.get(formula.size()-1))){
                    formula.add(plus.getText().toString());
                }
                String str="";
                for (int i=0;i<formula.size();i++){
                    str+=formula.get(i);
                }
                process.setText(str);

            }
        });
        button0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                formula.add(button0.getText().toString());
                String str="";
                for (int i=0;i<formula.size();i++){
                    str+=formula.get(i);
                }
                process.setText(str);
            }
        });
        dot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(formula.isEmpty()){
                    process.setText("");
                }else if(!isOperator(formula.get(formula.size()-1))) {
                    formula.add(dot.getText().toString());
                }
                String str="";
                for (int i=0;i<formula.size();i++){
                    str+=formula.get(i);
                }
                process.setText(str);

            }
        });
        equals.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String res="0";
                if(!formula.isEmpty()){ //防止只按等号报错
                    res = compute(formula);
                }
                result.setText(res);
                ANS=res;
            }
        });
        zuokuohao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                formula.add(zuokuohao.getText().toString());
                String str="";
                for (int i=0;i<formula.size();i++){
                    str+=formula.get(i);
                }
                process.setText(str);
            }
        });
        youkuohao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                formula.add(youkuohao.getText().toString());
                String str="";
                for (int i=0;i<formula.size();i++){
                    str+=formula.get(i);
                }
                process.setText(str);
            }
        });

    }
    //用堆栈实现四则运算,使用后缀表达式直接计算
    private String compute( List<String> formula) {
        String res = "";
        Stack<Float> nums = new Stack<Float>(); // 保存数字
        Stack<String> opes = new Stack<String>(); // 保存操作符
        int formula_length = formula.size();
        float k=0;// 保存每一个数字
        int dot_n=1;//小数点后第几位
        int digit=-1;
        boolean afterdot=false;
        for (int i = 0; i < formula_length;i++) {
            String temp = formula.get(i);
            if (isDigit(formula.get(i)) || formula.get(i).equals(".")) {
                if(formula.get(i).equals(".")){
                    afterdot=true;
                    continue;
                }
                if(afterdot){
                    dot_n*=10;
                    k= k+ Float.parseFloat(formula.get(i))/dot_n; // 注意这里不能改成  *0.1 会得到错误结果
                    digit=0;
                }
                else {
                    k = k * 10 + Integer.parseInt(formula.get(i)); // 大于10的数字保存
                    digit=0;
                }
            } else {
                if (digit!= -1) {
                    nums.push(k);
                    k = 0;
                    digit=-1;
                    afterdot=false;
                }
                if (temp.equals("(")) {
                    opes.push(temp);
                } else if (temp.equals(")")) {
                    while (!opes.peek().equals("(")) { // 括号里面运算完
                        if(opes.peek().equals("-") && nums.size()==1){
                            float s=nums.pop();
                            s=-s;//取负数
                            nums.push(s);
                            opes.pop();
                        } else if(nums.size()<=1){
                            return "error!";
                        } else {
                            float t = cal(nums.pop(), nums.pop(), opes.pop());
                            nums.push(t);
                        }
                    }
                    opes.pop();
                } else if (isType(temp) > 0) {
                    if (opes.isEmpty()) { // 栈为空直接入栈
                        opes.push(temp);
                    } else {
                        // 若栈顶元素优先级大于或等于要入栈的元素,将栈顶元素弹出并计算,然后入栈
                        if (isType(opes.peek()) >= isType(temp)) {
                            if(isType(opes.peek())==3){
                                float t = TrigonometricFunction(nums.pop(),opes.pop());
                                nums.push(t);
                            }else{
                                float t = cal(nums.pop(), nums.pop(), opes.pop());
                                nums.push(t);
                            }
                        }
                        opes.push(temp);
                    }
                }
            }
        }
        // 最后一个字符若是数字,未入栈
        if (digit != -1) {
            nums.push(k);
        }
        while (!opes.isEmpty()) {
            //表明此数为负数
            if(opes.peek().equals("-") && nums.size()==1 && !isOperator(formula.get(formula_length-1))){
                float s=nums.pop();
                s=-s;//取负数
                nums.push(s);
                opes.pop();
            } else if(isType(opes.peek())==3){
                float t = TrigonometricFunction(nums.pop(),opes.pop());
                nums.push(t);
            } else if(opes.peek().equals("(") || nums.size()<=1
                    ||isOperator(formula.get(formula_length-1))){
                return "error!";
            } else{
                float t = cal(nums.pop(), nums.pop(), opes.pop());
                nums.push(t);
            }
        }
        res=nums.pop().toString();
        if(res.substring(res.length()-2, res.length()).equals(".0"))  //如果结果为整数，将结果显示为整数形式
        {
            res=res.substring(0,res.length()-2);
        }
        return res;
    }
    // 返回是否为数字
    public static boolean isDigit(String c) {
        return c.equals("0") || c.equals("1")|| c.equals("2")|| c.equals("3")
                || c.equals("4")|| c.equals("5")|| c.equals("6")|| c.equals("7")
                || c.equals("8")|| c.equals("9");
    }
    //返回是否为四则运算符
    public static boolean isOperator(String c) {
        return c.equals("+") || c.equals("-")|| c.equals("×")|| c.equals("÷")
                ||c.equals(".");
    }
    // 返回的是运算符的优先级,数字和()不需要考虑
    public static int isType(String c) {
        if(c.equals("sin") || c.equals("cos") || c.equals("tan") || c.equals("cot")){
            return 3;
        } else if (c.equals("×") || c.equals("÷") ) {
            return 2;
        } else if (c.equals("+") || c .equals("-") ) {
            return 1;
        } else {
            return 0;
        }
    }
    // 运算次序是反的,跟入栈出栈次序有关
    //为了防止精度丢失，这里使用BigDecimal进行四则运算
    public static float cal(float m, float n, String c) {
        BigDecimal sum = null;
        BigDecimal b1 = new BigDecimal(Float.toString(m));
        BigDecimal b2 = new BigDecimal(Float.toString(n));
        if (c.equals("+")) {
            sum=b2.add(b1);
        } else if (c.equals("-") ) {
            sum=b2.subtract(b1);
        } else if (c.equals("×") ) {
            sum=b2.multiply(b1);
        } else if (c.equals("÷") ) {
            sum=b2.divide(b1,6, BigDecimal.ROUND_HALF_UP);
        }
        return sum.floatValue();
    }
    //三角函数
    public static float  TrigonometricFunction(float m, String c) {
        BigDecimal sum = null;
        double res = 0;
        double x=Double.parseDouble(String.valueOf(m));
        x = Math.toRadians(x);
        //BigDecimal b1 = new BigDecimal(Float.toString(m));
        if (c.equals("sin")) {
            res=Math.sin(x);
        } else if (c.equals("cos") ) {
            res=Math.cos(x);
        } else if (c.equals("tan") ) {
            res= Math.tan(x);
        } else if (c.equals("cot") ) {
            res=1/Math.tan(x);
        }
        sum=new BigDecimal(res).setScale(6, BigDecimal.ROUND_HALF_UP);
        return sum.floatValue();
    }

    private void showPopupWindow_more() {
        //设置contentView
        View contentView = LayoutInflater.from(this).inflate(R.layout.more_button, null);
        PopupWindow mPopWindow = new PopupWindow(contentView,
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, true);
        mPopWindow.setContentView(contentView);
        mPopWindow.setFocusable(true);
        Activity activity = this;
        startbgAnimation(activity, true);
        //设置各个控件的点击响应
        TextView holidays = contentView.findViewById(R.id.holidays);
        holidays.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mPopWindow.dismiss();
                Intent intent = new Intent(HomePage.this,Holidays.class);
                startActivity(intent);
            }
        });
        TextView exams = contentView.findViewById(R.id.exams);
        exams.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mPopWindow.dismiss();
                Intent intent = new Intent(HomePage.this,Exams.class);
                startActivity(intent);
            }
        });
        TextView edges = contentView.findViewById(R.id.edges3);
        edges.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mPopWindow.dismiss();
                Intent intent = new Intent(HomePage.this,Edges3.class);
                startActivity(intent);
            }
        });
        TextView bmi = contentView.findViewById(R.id.bmi);
        bmi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mPopWindow.dismiss();
                Intent intent = new Intent(HomePage.this,BMITest.class);
                startActivity(intent);
            }
        });
        TextView speed = contentView.findViewById(R.id.speed);
        speed.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mPopWindow.dismiss();
                Intent intent = new Intent(HomePage.this,SpeedTest.class);
                startActivity(intent);
            }
        });
        TextView pepredict = contentView.findViewById(R.id.PE);
        pepredict.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mPopWindow.dismiss();
                Intent intent = new Intent(HomePage.this,PEpredict.class);
                startActivity(intent);
            }
        });
        //显示PopupWindow
        //添加弹出、弹入的动画
        mPopWindow.setAnimationStyle(R.style.Popupwindow);
        int[] location = new int[2];
        contentView.getLocationOnScreen(location);
        mPopWindow.showAtLocation(contentView, Gravity.LEFT | Gravity.BOTTOM, 0, -location[1]);
        //弹窗消失时恢复背景颜色
        mPopWindow.setOnDismissListener(new PopupWindow.OnDismissListener() {
            @Override
            public void onDismiss() {
                startbgAnimation(activity, false);
            }
        });
    }

    //设置打开和关闭“删除评论”弹窗时背景颜色的变化
    private void startbgAnimation(Activity context, boolean isEnter) {
        float start;
        float end;
        if (isEnter) {
            start = 1f;
            end = 0.7f;
        } else {
            start = 0.7f;
            end = 1f;
        }
        WindowManager.LayoutParams wlp = context.getWindow().getAttributes();
        ValueAnimator valueAnimator = ValueAnimator.ofFloat(start, end);
        valueAnimator.setDuration(400);
        valueAnimator.setRepeatCount(0);
        valueAnimator.addUpdateListener(animation -> {
            wlp.alpha = (float) animation.getAnimatedValue();
            context.getWindow().setAttributes(wlp);
        });
        valueAnimator.start();
    }
}