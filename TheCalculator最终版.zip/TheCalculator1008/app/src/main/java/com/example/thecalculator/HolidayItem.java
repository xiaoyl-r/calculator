package com.example.thecalculator;

import java.util.Date;

public class HolidayItem {
    public String text;
    public String time;

    public HolidayItem setData(String text,String time) {
        this.time = time;
        this.text = text;
        return this;
    }

    String getText(){
        return this.text;
    }

    String getTime(){
        return this.time;
    }
}
