package com.example.thecalculator;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class Holidays extends AppCompatActivity {

    private HolidayItemAdapter holidayItemAdapter;
    private List<HolidayItem> holidayItems;
    private RecyclerView rv_holidayitems;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_holidays);

        rv_holidayitems = findViewById(R.id.recycler_holidays);
        holidayItems = new ArrayList<>();
        Calendar calendar = Calendar.getInstance();  //当前日期
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        Date current_date = calendar.getTime();

        Date yuandan =null;
        Date chunjie = null;
        Date guoqin = null;
        Date hanjia = null;
        Date qingming = null;
        Date duanwu = null;
        try {
            yuandan = formatter.parse("2022-01-01");
            chunjie = formatter.parse("2022-02-01");
            guoqin = formatter.parse("2022-10-01");
            hanjia = formatter.parse("2022-01-10");
            qingming = formatter.parse("2022-04-04");
            duanwu = formatter.parse("2022-06-03");
        } catch (ParseException e) {
            e.printStackTrace();
        }

        long i1 = 0;
        i1 = yuandan.getTime() - current_date.getTime();
        String days1 = String.valueOf(i1 / (1000 * 60 * 60 * 24));
        i1 = chunjie.getTime() - current_date.getTime();
        String days2 = String.valueOf(i1 / (1000 * 60 * 60 * 24));
        i1 = guoqin.getTime() - current_date.getTime();
        String days3 = String.valueOf(i1 / (1000 * 60 * 60 * 24));
        i1 = hanjia.getTime() - current_date.getTime();
        String days4 = String.valueOf(i1 / (1000 * 60 * 60 * 24));
        i1 = qingming.getTime() - current_date.getTime();
        String days5 = String.valueOf(i1 / (1000 * 60 * 60 * 24));
        i1 = duanwu.getTime() - current_date.getTime();
        String days6 = String.valueOf(i1 / (1000 * 60 * 60 * 24));

        holidayItems.add(new HolidayItem().setData("距离元旦还有",days1));
        holidayItems.add(new HolidayItem().setData("距离春节还有",days2));
        holidayItems.add(new HolidayItem().setData("距离国庆节还有",days3));
        holidayItems.add(new HolidayItem().setData("距离寒假还有",days4));
        holidayItems.add(new HolidayItem().setData("距离清明节还有",days5));
        holidayItems.add(new HolidayItem().setData("距离端午节还有",days6));
        RecyclerView.LayoutManager manager = new LinearLayoutManager(Holidays.this);
        rv_holidayitems.setLayoutManager(manager);
        holidayItemAdapter = new HolidayItemAdapter(holidayItems);
        rv_holidayitems.setAdapter(holidayItemAdapter);
    }
}