package com.example.thecalculator;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class Exams extends AppCompatActivity {

    private HolidayItemAdapter holidayItemAdapter;
    private List<HolidayItem> examsItems;
    private RecyclerView rv_examitems;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_holidays);

        Calendar calendar = Calendar.getInstance();  //当前日期
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        Date current_date = calendar.getTime();

        Date siliuji =null;
        Date acca = null;
        Date cpa = null;
        Date shumo = null;
        Date yingyujingsai = null;
        Date shuxuejingsai = null;
        try {
            siliuji = formatter.parse("2021-12-18");
            acca = formatter.parse("2021-12-06");
            cpa = formatter.parse("2022-08-26");
            shumo = formatter.parse("2022-09-10");
            yingyujingsai = formatter.parse("2022-04-24");
            shuxuejingsai = formatter.parse("2021-10-30");
        } catch (ParseException e) {
            e.printStackTrace();
        }

        long i1 = 0;
        i1 = siliuji.getTime() - current_date.getTime();
        String days1 = String.valueOf(i1 / (1000 * 60 * 60 * 24));
        i1 = acca.getTime() - current_date.getTime();
        String days2 = String.valueOf(i1 / (1000 * 60 * 60 * 24));
        i1 = cpa.getTime() - current_date.getTime();
        String days3 = String.valueOf(i1 / (1000 * 60 * 60 * 24));
        i1 = shumo.getTime() - current_date.getTime();
        String days4 = String.valueOf(i1 / (1000 * 60 * 60 * 24));
        i1 = yingyujingsai.getTime() - current_date.getTime();
        String days5 = String.valueOf(i1 / (1000 * 60 * 60 * 24));
        i1 = shuxuejingsai.getTime() - current_date.getTime();
        String days6 = String.valueOf(i1 / (1000 * 60 * 60 * 24));

        rv_examitems = findViewById(R.id.recycler_holidays);
        examsItems = new ArrayList<>();
        examsItems.add(new HolidayItem().setData("距四六级",days1));
        examsItems.add(new HolidayItem().setData("距ACCA",days2));
        examsItems.add(new HolidayItem().setData("距CPA",days3));
        examsItems.add(new HolidayItem().setData("距数学建模大赛",days4));
        examsItems.add(new HolidayItem().setData("距全国英语竞赛(暂定)",days5));
        examsItems.add(new HolidayItem().setData("距全国数学竞赛",days6));
        RecyclerView.LayoutManager manager = new LinearLayoutManager(Exams.this);
        rv_examitems.setLayoutManager(manager);
        holidayItemAdapter = new HolidayItemAdapter(examsItems);
        rv_examitems.setAdapter(holidayItemAdapter);
    }
}