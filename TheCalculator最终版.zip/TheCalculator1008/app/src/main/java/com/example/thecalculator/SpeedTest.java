package com.example.thecalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ActivityInfo;
import android.media.AudioManager;
import android.media.SoundPool;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.SystemClock;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Chronometer;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import java.text.SimpleDateFormat;

import java.util.Date;
import java.util.HashMap;
import java.util.Random;

public class SpeedTest extends AppCompatActivity {
    /************1.定义变量、对象、洞穴坐标******************/
    private int i=0;//记录打到的地鼠个数
    private ImageView mouse;//定义 mouse 对象
    private TextView info1; //定义 info1 对象（用于查看洞穴坐标）
    private Handler handler;//声明一个 Handler 对象
    private TextView pos1,pos2,pos3,pos4,pos5,pos6,pos7,pos8,pos9;
    public int[] position1=new int[2],position2=new int[2],position3=new int[2],position4=new int[2],
            position5=new int[2],position6=new int[2],position7=new int[2],position8=new int[2],position9=new int[2];
    private int[][] position;
    private TextView speed_res,btn_start;
    private Chronometer gameTime;

    /**
     * 规定开始音乐、暂停音乐、结束音乐的标志
     */
    public  static final int PLAT_MUSIC=1;
    public  static final int PAUSE_MUSIC=2;
    public  static final int STOP_MUSIC=3;

    private MyBroadCastReceiver receiver;
    //检测系统时间
    SimpleDateFormat formatter= new SimpleDateFormat("HH:mm:ss:SSS");
    Date curDate,touchDate;


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_speed_test);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);//设置不显示顶部栏
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);//设置横屏模式
        /************2.绑定控件*****************/
        mouse = (ImageView) findViewById(R.id.imageView1);
        info1 = findViewById(R.id.info);
        speed_res = findViewById(R.id.speed_res);
        btn_start = findViewById(R.id.btn_start);
        gameTime = findViewById(R.id.gameTime);
        findViews();
        position=new int[][]{
                position1,position2,position3,position4,position5,
                position6,position7,position8,position9
        }; //创建一个表示地鼠位置的数组 @Override
        //背景音乐设置
        receiver=new MyBroadCastReceiver();
        IntentFilter filter=new IntentFilter();
        filter.addAction("com.complete");
        registerReceiver(receiver,filter);
        //进入系统开始音乐(默认循环播放）
        playingmusic(PLAT_MUSIC);
        playingmusic(PLAT_MUSIC);

        /************获取洞穴位置*****************/
        //通过 logcat 查看 【注】：getRawY()：触摸点距离屏幕上方的长度（此长度包括程序项目名栏的）
        info1.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        float x = event.getRawX();
                        float y = event.getRawY();
                        Log.i("x:" + x, "y:" + y);
                        break;
                    default:
                        break;
                }
                return false;
            }
        });

        /************4.实现点击地鼠后的事件：让地鼠不显示&显示消息*****************/
        // 添加触摸 mouse 后的事件
        mouse.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                v.setVisibility(View.INVISIBLE);//设置地鼠不显示
                touchDate = new Date(System.currentTimeMillis());
                i++;
                long speed_ms=touchDate.getTime()-curDate.getTime();
                if(speed_ms<150){
                    speed_res.setText("反应时间:"+speed_ms+"ms,您的反应速度比刘翔还快！");
                } else if(speed_ms<400){
                    speed_res.setText("反应时间:"+speed_ms+"ms,哎哟不错哦。");
                } else {
                    speed_res.setText("反应时间:"+speed_ms+"ms,你比正常人稍稍慢了点。");
                }
                return false;
            }
        });
    }

    @Override
    public void onWindowFocusChanged(boolean hasWindowFocus) {
        pos1.getLocationOnScreen(position1);
        pos2.getLocationOnScreen(position2);
        pos3.getLocationOnScreen(position3);
        pos4.getLocationOnScreen(position4);
        pos5.getLocationOnScreen(position5);
        pos6.getLocationOnScreen(position6);
        pos7.getLocationOnScreen(position7);
        pos8.getLocationOnScreen(position8);
        pos9.getLocationOnScreen(position9);
        super.onWindowFocusChanged(hasWindowFocus);
    }

    private void findViews(){
        pos1=findViewById(R.id.pos1);
        pos2=findViewById(R.id.pos2);
        pos3=findViewById(R.id.pos3);
        pos4=findViewById(R.id.pos4);
        pos5=findViewById(R.id.pos5);
        pos6=findViewById(R.id.pos6);
        pos7=findViewById(R.id.pos7);
        pos8=findViewById(R.id.pos8);
        pos9=findViewById(R.id.pos9);
    }
    public void onClick(View view){
        switch (view.getId()){
            //开始音乐
            case R.id.btn_startmusic:
                playingmusic(PLAT_MUSIC);
                break;
            //暂停
           /* case R.id.btn_pausemusic:
                playingmusic(PAUSE_MUSIC);
                break;
           */
            //停止
            case R.id.btn_stopmusic:
                playingmusic(STOP_MUSIC);
                break;
            case R.id.btn_exit:
                finish();
                playingmusic(STOP_MUSIC);
                break;
            case R.id.btn_start:
                start();
                break;
        }
    }
    private void playingmusic(int type) {
        //启动服务，播放音乐
        Intent intent=new Intent(this,PlayingMusicServices.class);
        intent.putExtra("type",type);
        startService(intent);
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        unregisterReceiver(receiver);
    }
    private void start(){
        //游戏时间30s后询问是否继续游戏
        AlertDialog.Builder  builder = new AlertDialog.Builder(this);
        builder.setTitle("是否继续游戏？");
        builder.setMessage("选择继续将重新开始游戏！");
        builder.setPositiveButton("继续", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                gameTime.setBase(SystemClock.elapsedRealtime());
                gameTime.start();
            }
        });
        builder.setNegativeButton("退出", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                finish();
                playingmusic(STOP_MUSIC);
            }
        });
        gameTime.setBase(SystemClock.elapsedRealtime());//设置计时初值
        gameTime.setFormat("%s");//设置格式
        gameTime.start();//开始计时
        gameTime.setOnChronometerTickListener(new Chronometer.OnChronometerTickListener() {
            @Override
            public void onChronometerTick(Chronometer chronometer) {
                if (SystemClock.elapsedRealtime()-gameTime.getBase()>=30000){
                    gameTime.stop();
                    builder.show();
                }
            }
        });
        /************3.实现地鼠随机出现*****************/
        //创建 Handler 消息处理机制
        handler = new Handler() {
            @Override
            public void handleMessage(@NonNull Message msg) {
                //需要处理的消息
                int index;
                if (msg.what == 0x101) {
                    index = msg.arg1;//// 获取位置索引值
                    mouse.setX(position[index][0]);//设置 X 轴坐标
                    mouse.setY(position[index][1]);//设置 Y 轴坐标（原点为屏幕左上角（不包括程序名称栏））
                    mouse.setVisibility(View.VISIBLE);//设置地鼠显示
                    curDate = new Date(System.currentTimeMillis());// new Date()为获取当前系统时间
                }
                super.handleMessage(msg);
            }
        };
        // 创建线程
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                int index = 0;// 定义一个记录地鼠位置的索引值
                while (!Thread.currentThread().isInterrupted()) {
                    index = new Random().nextInt(position.length);// 产生一个随机整数（范围：0<=index<数组长度）
                    Message m = handler.obtainMessage();//创建消息对象
                    m.what = 0x101;//设置消息标志
                    m.arg1 = index;// 保存地鼠标位置的索引值
                    handler.sendMessage(m);// 发送消息通知 Handler 处理
                    try {
                        Thread.sleep(new Random().nextInt(5000)); // 休眠一段时间
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        });
        t.start();
    }
}